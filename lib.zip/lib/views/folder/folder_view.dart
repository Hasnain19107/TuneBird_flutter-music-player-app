import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controllers/folder_controller.dart';
import '../../models/directory_info_model.dart';
import '../player/player_view.dart';
import '../common/mini_player.dart';
import '../common/song_list_view.dart';
import '../../services/music_service.dart';
import '../../models/song_model.dart';

class FolderView extends StatelessWidget {
  const FolderView({super.key});

  @override
  Widget build(BuildContext context) {
    final folderController = Get.find<FolderController>();

    return Obx(() {
      return Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  children: [
                    Text(
                      folderController.isScanning.value 
                          ? 'Scanning...' 
                          : '${folderController.audioDirectories.length} Folders',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.refresh),
                      onPressed: folderController.isScanning.value 
                          ? null 
                          : () => folderController.refreshFolders(),
                      tooltip: 'Refresh folders',
                    ),
                  ],
                ),
                if (!folderController.isScanning.value && 
                    folderController.audioDirectories.isNotEmpty &&
                    folderController.lastScanTime.value.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4.0),
                    child: Text(
                      'Last scanned: ${folderController.lastScanTime.value}',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                    ),
                  ),
              ],
            ),
          ),

          // Content
          Expanded(
            child: folderController.isScanning.value
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const CircularProgressIndicator(),
                        const SizedBox(height: 16),
                        Text(folderController.scanStatus.value.isEmpty 
                            ? 'Scanning...' 
                            : folderController.scanStatus.value),
                      ],
                    ),
                  )
                : folderController.audioDirectories.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.folder_off, size: 64, color: Colors.grey),
                            const SizedBox(height: 16),
                            const Text('No audio folders found'),
                            const SizedBox(height: 8),
                            TextButton(
                              onPressed: () => folderController.refreshFolders(),
                              child: const Text('Scan Again'),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: folderController.audioDirectories.length,
                        itemBuilder: (context, index) {
                          final dir = folderController.audioDirectories[index];
                          return Card(
                            margin: const EdgeInsets.only(bottom: 12),
                            elevation: 2,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: ListTile(
                              contentPadding: const EdgeInsets.all(16),
                              leading: Container(
                                width: 50,
                                height: 50,
                                decoration: BoxDecoration(
                                  color: Colors.orange.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: const Icon(
                                  Icons.folder,
                                  color: Colors.orange,
                                  size: 28,
                                ),
                              ),
                              title: Text(
                                dir.name,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                ),
                              ),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(height: 4),
                                  Text(
                                    '${dir.audioFileCount} audio files',
                                    style: TextStyle(
                                      color: Colors.grey[600],
                                      fontSize: 14,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    dir.path,
                                    style: TextStyle(
                                      color: Colors.grey[500],
                                      fontSize: 12,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.play_circle_fill),
                                    onPressed: () async {
                                      await folderController.playDirectory(dir, startIndex: 0);
                                      Get.to(() => const PlayerView());
                                    },
                                    color: Theme.of(context).primaryColor,
                                    tooltip: 'Play all',
                                  ),
                                  const Icon(Icons.chevron_right),
                                ],
                              ),
                              onTap: () => _openDirectory(context, dir),
                            ),
                          );
                        },
                      ),
          ),
        ],
      );
    });
  }

  void _openDirectory(BuildContext context, DirectoryInfo dirInfo) {
    Get.to(() => DirectoryDetailView(directoryInfo: dirInfo));
  }

  // Removed playback logic; now handled by controller.
}

// Simplified, controller-driven detail view
class DirectoryDetailView extends StatefulWidget {
  final DirectoryInfo directoryInfo;
  const DirectoryDetailView({super.key, required this.directoryInfo});

  @override
  State<DirectoryDetailView> createState() => _DirectoryDetailViewState();
}

class _DirectoryDetailViewState extends State<DirectoryDetailView> {
  late List<Song> _folderSongs;

  @override
  void initState() {
    super.initState();
    final folderController = Get.find<FolderController>();
    _folderSongs = folderController.buildSongsForDirectory(widget.directoryInfo);
  }

  // _refreshSongs removed (not currently used). Add if pull-to-refresh needed later.

  @override
  Widget build(BuildContext context) {
    final folderController = Get.find<FolderController>();
    return Scaffold(
      appBar: AppBar(title: Text(widget.directoryInfo.name)),
      body: Column(
        children: [
          Expanded(
            child: SongListView(
              titleSingular: 'Songs',
              customSongs: _folderSongs,
              showActions: true,
              header: Container(
                padding: const EdgeInsets.fromLTRB(16,16,16,8),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.folder, color: Colors.orange, size: 32),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(widget.directoryInfo.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          Text('${_folderSongs.length} songs', style: TextStyle(color: Colors.grey[600], fontSize: 14)),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.play_circle_fill),
                      tooltip: 'Play All',
                      onPressed: () async {
                        await folderController.playDirectory(widget.directoryInfo, startIndex: 0);
                        Get.to(() => const PlayerView());
                      },
                    )
                  ],
                ),
              ),
              onShuffle: () async {
                final songs = folderController.buildSongsForDirectory(widget.directoryInfo);
                songs.shuffle();
                final ms = Get.find<MusicService>();
                await ms.setTemporaryQueue(songs, startIndex: 0);
                setState(() { _folderSongs = songs; });
              },
              onPlayAll: () async {
                await folderController.playDirectory(widget.directoryInfo, startIndex: 0);
                Get.to(() => const PlayerView());
              },
              onSongTap: (song, idx) async {
                await folderController.playSongInDirectory(widget.directoryInfo, idx);
                Get.to(() => const PlayerView());
              },
            ),
          ),
          const MiniPlayer(),
        ],
      ),
    );
  }
}
