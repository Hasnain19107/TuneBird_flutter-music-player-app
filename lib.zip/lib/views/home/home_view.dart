import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../viewmodels/music_viewmodel.dart';
import '../../services/music_service.dart';
import '../player/player_view.dart';
import '../playlists/playlists_view.dart';
import '../search/search_view.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  @override
  void initState() {
    super.initState();
    // Request permissions after the widget is built to avoid the crash
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _requestPermissionsDelayed();
    });
  }

  Future<void> _requestPermissionsDelayed() async {
    try {
      final musicService = Get.find<MusicService>();
      await Future.delayed(
          const Duration(seconds: 2)); // Wait for app to fully load

      print('Requesting permissions from HomeView...');
      bool success = await musicService.requestPermissionsIfNeeded();

      if (success) {
        print('Permissions granted successfully');
      } else {
        print('Permissions were not granted');
      }
    } catch (e) {
      print('Error requesting permissions from HomeView: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = Get.find<MusicViewModel>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Music Player'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => Get.to(() => const SearchView()),
          ),
          IconButton(
            icon: const Icon(Icons.playlist_play),
            onPressed: () => Get.to(() => const PlaylistsView()),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Obx(() {
              if (viewModel.songs.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.music_note,
                          size: 64, color: Colors.grey),
                      const SizedBox(height: 16),
                      const Text('No songs found'),
                      const SizedBox(height: 8),
                      TextButton(
                        onPressed: _requestPermissionsDelayed,
                        child: const Text('Grant Permissions'),
                      ),
                    ],
                  ),
                );
              }
              return ListView.builder(
                itemCount: viewModel.songs.length,
                itemBuilder: (context, index) {
                  final song = viewModel.songs[index];
                  return ListTile(
                    leading: const CircleAvatar(
                      child: Icon(Icons.music_note),
                    ),
                    title: Text(song.title),
                    subtitle: Text(song.artist),
                    onTap: () {
                      viewModel.playSong(index);
                      Get.to(() => const PlayerView());
                    },
                  );
                },
              );
            }),
          ),
          Obx(() {
            if (viewModel.currentSong != null) {
              return MiniPlayer(viewModel: viewModel);
            }
            return const SizedBox.shrink();
          }),
        ],
      ),
    );
  }
}

class MiniPlayer extends StatelessWidget {
  final MusicViewModel viewModel;

  const MiniPlayer({
    super.key,
    required this.viewModel,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Get.to(() => const PlayerView()),
      child: Container(
        height: 60,
        color: Theme.of(context).primaryColor.withOpacity(0.1),
        child: Row(
          children: [
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    viewModel.currentSong?.title ?? '',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    viewModel.currentSong?.artist ?? '',
                    style: const TextStyle(fontSize: 12),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            IconButton(
              icon: Obx(() => Icon(
                    viewModel.isPlaying.value ? Icons.pause : Icons.play_arrow,
                  )),
              onPressed: viewModel.togglePlay,
            ),
            IconButton(
              icon: const Icon(Icons.skip_next),
              onPressed: viewModel.nextSong,
            ),
            const SizedBox(width: 8),
          ],
        ),
      ),
    );
  }
}
